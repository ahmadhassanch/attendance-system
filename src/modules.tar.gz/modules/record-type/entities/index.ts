export * from './record-type.entity';
